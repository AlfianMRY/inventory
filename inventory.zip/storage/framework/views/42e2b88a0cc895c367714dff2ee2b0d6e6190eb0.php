
<?php $__env->startSection('header'); ?>
<div class="row justify-content-between align-content-center">
    <div class="col-md-3">
        <h3>Daftar Barang <?php echo e($search ? $search : ''); ?></h3>
    </div>
    
    <div class="col-md-4 ">
        <form action="<?php echo e(url('/list-barang')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mt-1">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control" name="search" placeholder="Search">
                <button class="btn btn-info" type="submit">Search <i class="uil uil-search-alt"></i></button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row ">
        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            if($b->stock >= 100){
                $bg = 'success';
                $title = 'Ready';
            }elseif ($b->stock >= 1 && $b->stock < 100) {
                $bg = 'warning';
                $title = 'Hampir Habis';
            }else {
                $bg = 'danger';
                $title = 'Habis';
            }
        ?>
        <div class="col-md-4 col-lg-3 col-sm-6">
            <!-- Simple card -->
            <div class="card d-block ribbon-box border-info border ">
                <img class="card-img-top" src="<?php echo e(asset('/img/barang/'.$b->foto)); ?>" alt="Card image cap">
                <div class="card-body">
                    <div class="ribbon-two ribbon-two-<?php echo e($bg); ?>"><span><?php echo e($title); ?></span></div>
                    <h5 class="card-title text-info"><?php echo e($b->nama); ?></h5>
                    <p class="card-text">Stock : <?php echo e($b->stock); ?></p>
                    <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#standard-modal<?php echo e($b->id); ?>" <?php echo e($b->stock <= 0 ? 'disabled' : ''); ?>>Pesan</button>
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div><!-- end col -->

        <!-- Standard modal -->
        <div id="standard-modal<?php echo e($b->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="standard-modalLabel" aria-hidden="true">
            <div class="modal-dialog  modal-dialog-centered">
                <div class="modal-content">
                    <form action="<?php echo e(url('/tambah-req')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h4 class="modal-title" id="standard-modalLabel">Pesan : <?php echo e($b->nama); ?></h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                        </div>
                        <img class="card-img-top" src="<?php echo e(asset('/img/barang/'.$b->foto)); ?>" alt="Card image cap">
                        <div class="modal-body">
                            <input type="hidden" name="barang_id" value="<?php echo e($b->id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="status" value="menunggu">
                            <div class="mb-3">
                                <label for="simpleinput" class="form-label">Quantity</label>
                                <input type="number" name="quantity" max="<?php echo e($b->stock); ?>" id="simpleinput" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="example-textarea" class="form-label">Keterangan</label>
                                <textarea name="keterangan" class="form-control" id="example-textarea" rows="3" placeholder="Keperluan Anda"></textarea>
                            </div>
                            <input type="hidden" name="tanggal_request" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/list-barang.blade.php ENDPATH**/ ?>