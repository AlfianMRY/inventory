
<?php $__env->startSection('header'); ?>
    <h3>Tambah Data Kategori</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('/kategori')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="row mb-2">
            <label  class="col-2 col-form-label">Nama Kategori : </label>
            <div class="col-10">
                <input type="text" name="nama" class="form-control"  placeholder="Nama Kategori">
            </div>
        </div>   
    </div>
    <div class="mt-2 d-flex">
        <a href="<?php echo e(url('/kategori')); ?>" class="btn btn-danger rounded-pill mr-2">Cancel</a>
        <button type="submit" class="btn btn-success rounded-pill mx-2">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/kategori/kategori-input.blade.php ENDPATH**/ ?>