
<?php $__env->startSection('header'); ?>
<div class="d-flex justify-content-between w-100 ">
    <h3>Edit Barang Masuk</h3>
    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-top'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show pt-2" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('/barang-masuk',$data->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="example-select" class="form-label">Pilih Barang</label>
            <select class="form-select select-option" name="barang" >
                <option  disabled> === Pilih Barang === </option>
                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($b->id); ?>" <?php echo e($data->barang_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label for="example-select" class="form-label">Pilih Supplier</label>
            <select class="form-select select-option" name="supplier" >
                <option  disabled> === Pilih Supplier === </option>
                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php echo e($data->supplier_id == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label for="example-date" class="form-label">Date</label>
            <input class="form-control" id="example-date" value="<?php echo e($data->tanggal_masuk); ?>" type="date" name="tgl_masuk">
        </div>
        <div class=" col-md-6 mb-3">
            <label class="form-label">Jumlah Barang Masuk</label>
            <input data-toggle="touchspin" value="<?php echo e($data->quantity); ?>" type="text" value="1" name="quantity" min="1" data-bts-button-down-class="btn btn-danger" data-bts-button-up-class="btn btn-success">
        </div>
    </div>
    <div class="mt-2 d-flex">
        <a href="<?php echo e(url('/barang-masuk')); ?>" class="btn btn-danger rounded-pill mr-2">Cancel</a>
        <button type="submit" class="btn btn-success rounded-pill mx-2">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    $('.select-option').select2();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/barangmasuk/edit.blade.php ENDPATH**/ ?>