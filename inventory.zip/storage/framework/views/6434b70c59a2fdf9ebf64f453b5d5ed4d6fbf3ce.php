<!DOCTYPE html>
<html>
<head>
<style>
    #customers {
    font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    #customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
    }

    #customers tr:nth-child(even){background-color: #f2f2f2;}

    #customers tr:hover {background-color: #ddd;}

    #customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #00e5ff;
    color: black;
    }
</style>
</head>
<body>
<center>
    <h1>Data Barang</h1>
    <h5><?php echo e($date); ?></h5>
</center>
    
<table id="customers">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Supplier</th>
            <th>No Hp</th>
            <th>Keterangan</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($d->nama); ?></td>
                <td><?php echo e($d->no_hp); ?></td>
                <td><?php echo e($d->keterangan); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\inventory\resources\views/pdf/supplier.blade.php ENDPATH**/ ?>