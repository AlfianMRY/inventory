
<?php $__env->startSection('css'); ?>
    <!-- Datatables css -->
<link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap5.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <h3 class="font-bold">Profile <?php echo e(ucwords($user->name)); ?></h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-top'); ?>
<div class="card bg-primary">
    <div class="card-body profile-user-box">
        <div class="row">
            <div class="col-sm-8">
                <div class="row align-items-center">
                    <div class="col-md-4 ">
                        <div class="avatar-lg mx-auto">
                            <?php
                                if (!empty($user->foto)) {
                                    $foto = $user->foto;
                                }else {
                                    $foto = 'default.png';
                                }
                                if ($user->status == 'active') {
                                    $stat = 'success';
                                }else{
                                    $stat = 'danger';
                                }
                            ?>
                            <img src="<?php echo e(asset('/img/profile/'.$foto)); ?>" alt="" class="rounded-circle img-thumbnail">
                        </div>
                    </div>
                    <div class="col">
                        <div>
                            <h4 class="mt-1 mb-1 text-white"><?php echo e($user->name); ?></h4>
                            <p class="font-13 text-white-50"> <?php echo e($user->email); ?></p>

                            <ul class="mb-0 list-inline text-light">
                                <li class="list-inline-item me-3">
                                    <h5 class="mb-1"><i class="mdi mdi-circle text-<?php echo e($stat); ?>"> </i> <?php echo e(ucwords($user->status)); ?></h5>
                                    <p class="mb-0 font-13 text-white-50">Status Akun</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5 class="mb-1">5482</h5>
                                    <p class="mb-0 font-13 text-white-50">Number of Orders</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> <!-- end col-->
            <div class="col-sm-4">
                <div class="text-center mt-sm-0 mt-3 text-sm-end">
                    <a href="<?php echo e(url('/user')); ?>" class="btn btn-light">
                        <i class="mdi mdi-account me-1"></i> Kembali
                    </a>
                </div>
            </div> <!-- end col-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3>Riwayat Request Barang</h3>
    <table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
        <thead>
            <tr>
                <th>No</th>
                <th>Barang</th>
                <th>Quantity</th>
                <th>Tanggal Request</th>
                <th>Status</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $user->request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                if ($d->status == 'menunggu') $stat = 'warning'; 
                if ($d->status == 'ditolak') $stat = 'danger'; 
                if ($d->status == 'disetujui') $stat = 'success'; 
            ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($d->barang->nama); ?></td>
                <td><?php echo e($d->quantity); ?></td>
                <td><?php echo e($d->tanggal_request); ?></td>
                <td><span class="badge bg-<?php echo e($stat); ?> "><?php echo e(ucwords($d->status)); ?></span></td>
                <td><?php echo e($d->keterangan); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Datatables js -->
<script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>

<!-- Datatable Init js -->
<script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/user/user-detail.blade.php ENDPATH**/ ?>