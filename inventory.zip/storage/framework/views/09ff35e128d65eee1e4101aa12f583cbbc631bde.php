
<?php $__env->startSection('css'); ?>
    <!-- Datatables css -->
    <link href="assets/css/vendor/dataTables.bootstrap5.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/vendor/responsive.bootstrap5.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<div class="d-flex justify-content-between w-100 ">
    <h4>Barang Masuk</h4>
    <a href="<?php echo e(url('/barang-masuk/create')); ?>" class="btn btn-success"> <i class="uil-file-plus-alt"></i> Tambah Barang Masuk</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-top'); ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <i class="dripicons-checkmark me-2"></i><strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $no = 1;
?>
<div class="d-flex">
    <div class="btn-group">
        <a href="<?php echo e(url('/pdf-barang-masuk')); ?>" class="btn btn-sm btn-danger mb-2">PDF</a>
        <a href="<?php echo e(url('/excel-barang-masuk')); ?>" class="btn btn-sm btn-success mb-2">Excel</a>
    </div>
</div>
<table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
    <thead>
        <tr>
            <th>No</th>
            <th>Barang</th>
            <th>Supplier</th>
            <th>Tanggal Masuk</th>
            <th>Jumlah Stock</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($d->barang->nama); ?></td>
            <td><?php echo e($d->supplier->nama); ?></td>
            <td><?php echo e($d->tanggal_masuk); ?></td>
            <td><?php echo e($d->quantity); ?></td>
            <th>
                <a href="<?php echo e(url('/barang-masuk/'.$d->id.'/edit')); ?>" class="btn btn-warning btn-sm"> Edit</a>
            </th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!-- Datatables js -->
    <script src="assets/js/vendor/jquery.dataTables.min.js"></script>
    <script src="assets/js/vendor/dataTables.bootstrap5.js"></script>
    <script src="assets/js/vendor/dataTables.responsive.min.js"></script>
    <script src="assets/js/vendor/responsive.bootstrap5.min.js"></script>
    
    <!-- Datatable Init js -->
    <script src="assets/js/pages/demo.datatable-init.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/barangmasuk/index.blade.php ENDPATH**/ ?>