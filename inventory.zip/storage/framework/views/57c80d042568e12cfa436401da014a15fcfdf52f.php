
<?php $__env->startSection('header'); ?>
    <h3>Edit Data Barang</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('/barang',$barang->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">Nama Barang :</label>
                <input type="text" value="<?php echo e($barang->nama); ?>" name="nama" id="simpleinput" class="form-control">
            </div>
        </div> 
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">Kode Barang :</label>
                <input type="text" value="<?php echo e($barang->kode); ?>" name="kode" id="simpleinput" class="form-control">
            </div>
        </div> 
        <div class="col-md-6">
            <div class="mb-3">
                <label for="example-select" class="form-label">Pilih Kategori :</label>
                <select name="kategori" class="form-select" id="example-select">
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($k->id == $barang->kategori_id ? 'selected' : ''); ?> value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">Stock Barang :</label>
                <input type="number" value="<?php echo e($barang->stock); ?>" name="stock" id="simpleinput" class="form-control">
            </div>
        </div> 
        <div class="col-md-6">
            <div class="mb-3">
                <label for="example-fileinput" class="form-label">Foto Barang :</label>
                <input type="file" name="foto" id="example-fileinput" class="form-control">
            </div>
        </div>
    </div>

    <div class="mt-2 d-flex">
        <a href="<?php echo e(url('/barang')); ?>" class="btn btn-danger rounded-pill mr-2">Cancel</a>
        <button type="submit" class="btn btn-success rounded-pill mx-2">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\laravel\resources\views/admin/barang/barang-edit.blade.php ENDPATH**/ ?>