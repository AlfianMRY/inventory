
<?php $__env->startSection('css'); ?>
    <!-- Datatables css -->
<link href="assets/css/vendor/dataTables.bootstrap5.css" rel="stylesheet" type="text/css" />
<link href="assets/css/vendor/responsive.bootstrap5.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <div class="d-flex justify-content-between w-100 ">
        <h4>Data Kategori</h4>
        <a href="<?php echo e(url('/kategori/create')); ?>" class="btn btn-success"> <i class="uil-file-plus-alt"></i> Tambah </a>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <i class="dripicons-checkmark me-2"></i><strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <i class="dripicons-wrong me-2"></i><strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>
<?php
    $no = 1;
?>
    <table id="basic-datatable" class="table dt-responsive nowrap w-100 table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th class="text-center">Action</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th width="10%"><?php echo e($no++); ?></th>
                    <td><?php echo e($d->nama); ?></td>
                    <td class="text-center" width="30%">
                        <form action="<?php echo e(url('/kategori',$d->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <a href="<?php echo e(url('/kategori/'.$d->id.'/edit')); ?>" class="btn btn-warning btn-sm"><i class="uil-file-edit-alt"></i> Edit</a>
                            <button type="submit"  onclick="return confirm('Yakin Hapus Data ini?')" class="btn btn-danger btn-sm"><i class=" uil-file-minus-alt"></i> Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!-- Datatables js -->
<script src="assets/js/vendor/jquery.dataTables.min.js"></script>
<script src="assets/js/vendor/dataTables.bootstrap5.js"></script>
<script src="assets/js/vendor/dataTables.responsive.min.js"></script>
<script src="assets/js/vendor/responsive.bootstrap5.min.js"></script>

<!-- Datatable Init js -->
<script src="assets/js/pages/demo.datatable-init.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/kategori/kategori.blade.php ENDPATH**/ ?>