
<?php $__env->startSection('header'); ?>
    <h3>Detail Barang</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Simple card -->
    <div class="card d-block">
        <img class="card-img-top" src="<?php echo e(asset('img/barang/'.$barang->foto)); ?>" alt="Card image cap">
        <div class="card-body">
            <h2 class="card-title">Nama Barang : <strong><?php echo e($barang->nama); ?></strong></h2>
            <h3>Kode Barang : <strong><?php echo e($barang->kode); ?></strong></h3>
            <h3>kategori Barang : <strong><?php echo e($barang->kategori->nama); ?></strong></h3>
            <a href="<?php echo e(url('/barang')); ?>" class="btn btn-primary">Kembali</a>
        </div> <!-- end card-body-->
    </div> <!-- end card-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/barang/barang-detail.blade.php ENDPATH**/ ?>