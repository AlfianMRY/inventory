
<?php $__env->startSection('header'); ?>
    <h3>Edit Data User <?php echo e($user->name); ?></h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('/user',$user->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="example-select" class="form-label">Role :</label>
            <select name="role" class="form-select" id="example-select">
                <option class="text-center" value="" disabled>=== Select Role === </option>
                <option <?php echo e($user->role == 'member' ? 'selected' : ''); ?> class="text-center" value="member">Member</option>
                <option <?php echo e($user->role == 'admin' ? 'selected' : ''); ?> class="text-center" value="admin">Admin</option>
            </select>
        </div>  
        <div class="col-md-6 mb-3">
            <label for="example-select" class="form-label">Status :</label>
            <select name="status" class="form-select" id="example-select">
                <option class="text-center" value="" disabled>=== Select Role === </option>
                <option <?php echo e($user->status == 'active' ? 'selected' : ''); ?> class="text-center" value="active">Active</option>
                <option <?php echo e($user->status == 'non active' ? 'selected' : ''); ?> class="text-center" value="non active">Non Active</option>
            </select>
        </div>   
    </div>
    <div class="mt-2 d-flex">
        <a href="<?php echo e(url('/user')); ?>" class="btn btn-danger rounded-pill mr-2">Cancel</a>
        <button type="submit" class="btn btn-success rounded-pill mx-2">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/user/user-edit.blade.php ENDPATH**/ ?>