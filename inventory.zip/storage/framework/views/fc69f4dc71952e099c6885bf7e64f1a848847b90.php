<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('landingpage/img/logolanding.png')); ?>"></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="<?php echo e(url('/')); ?>">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <?php if(auth()->guard()->guest()): ?>
            <li><a class="getstarted scrollto" href="<?php echo e(url('/login')); ?>">Login</a></li>  
          <?php else: ?>
            <li><a href="" class="nav-link scrollto disabled"><?php echo e(Auth::user()->name); ?></a></li>
            <li>
              <a class="nav-link scrollto" href="#" onclick="logout()">Logout</a> 
            </li>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
              </form>
          <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/landingpage/header.blade.php ENDPATH**/ ?>