<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #00e5ff;
  color: black;
}
</style>
</head>
<body>
<center>
    <h1>Data Barang Masuk</h1>
    <h5><?php echo e($date); ?></h5>
</center>
    
<table id="customers">
    <thead>
        <tr>
            <th>No</th>
            <th>Barang</th>
            <th>Supplier</th>
            <th>Tanggal Masuk</th>
            <th>Jumlah Stock</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($d->barang->nama); ?></td>
                <td><?php echo e($d->supplier->nama); ?></td>
                <td><?php echo e($d->tanggal_masuk); ?></td>
                <td><?php echo e($d->quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\inventory\resources\views/pdf/barang-masuk.blade.php ENDPATH**/ ?>