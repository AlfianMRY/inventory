<section id="about" class="about">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>About Us</h2>
      <div class="row">
        <div class="col-md-6 mx-auto">
          <p>Aplikasi inventory barang adalah sebuah program yang dirancang dalam mengelola, mengatur dan mengawasi segala hal mengenai pembelian barang dari supplier, stock opname, memantau jumlah pesanan pelanggan, hingga pembuatan laporan secara otomatis dan efisien.
          <br> Menggunakan software inventory barang dapat membantu dalam mengurangi biaya pengeluaran perusahaan sehingga akan lebih menguntungkan bagi bisnis Anda.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/landingpage/about.blade.php ENDPATH**/ ?>