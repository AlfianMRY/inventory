
<?php $__env->startSection('header'); ?>
    <h3>Tambah Data Supplier</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('/supplier')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">Nama Supplier :</label>
                <input type="text" name="nama" id="simpleinput" class="form-control">
            </div>
        </div>   
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">No HP :</label>
                <input type="number" name="no_hp" id="simpleinput" class="form-control">
            </div>
        </div>   
        <div class="mb-3">
            <label for="example-textarea" class="form-label">Keterangan</label>
            <textarea class="form-control" name="keterangan" id="example-textarea" rows="5"></textarea>
        </div>
    </div>
    <div class="mt-2 d-flex">
        <a href="<?php echo e(url('/supplier')); ?>" class="btn btn-danger rounded-pill mr-2">Cancel</a>
        <button type="submit" class="btn btn-success rounded-pill mx-2">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/supplier/supplier-input.blade.php ENDPATH**/ ?>