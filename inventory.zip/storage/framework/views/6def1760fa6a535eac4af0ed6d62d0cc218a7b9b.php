
<?php $__env->startSection('header'); ?>
    <h3>Tambah User</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('/user')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">Nama User :</label>
                <input type="text" name="nama" placeholder="Nama" id="simpleinput" class="form-control">
            </div>
        </div>   
        <div class="col-md-6">
            <div class="mb-3">
                <label for="simpleinput" class="form-label">Email User :</label>
                <input type="email" name="email" placeholder="exemple@gmail.com" id="simpleinput" class="form-control">
            </div>
        </div>   
        <div class="col-md-6 mb-3">
            <label for="password" class="form-label">Password :</label>
            <div class="input-group input-group-merge">
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password">
                <div class="input-group-text" data-password="false" style="cursor:pointer;">
                    <span class="password-eye"></span>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <label for="example-select" class="form-label">Role :</label>
            <select name="role" class="form-select" id="example-select">
                <option class="text-center" value="" selected disabled>=== Select Role === </option>
                <option class="text-center" value="member">Member</option>
                <option class="text-center" value="admin">Admin</option>
            </select>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label for="example-fileinput" class="form-label">Foto Profile :</label>
                <input type="file" name="foto" id="example-fileinput" class="form-control">
            </div>
        </div>
    </div>
    <div class="mt-2 d-flex">
        <a href="<?php echo e(url('/user')); ?>" class="btn btn-danger rounded-pill mr-2">Cancel</a>
        <button type="submit" class="btn btn-success rounded-pill mx-2">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/user/user-input.blade.php ENDPATH**/ ?>