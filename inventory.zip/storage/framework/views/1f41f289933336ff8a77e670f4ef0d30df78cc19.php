
<?php $__env->startSection('css'); ?>
    <!-- Datatables css -->
    <link href="assets/css/vendor/dataTables.bootstrap5.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/vendor/responsive.bootstrap5.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<div class="d-flex justify-content-between w-100 ">
    <h4>Request Barang</h4>
    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-top'); ?>

<ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
    <li class="nav-item">
        <a href="#menunggu" data-bs-toggle="tab" aria-expanded="true" onclick="menunggu()" class="nav-link rounded-0 active">
            <i class="mdi mdi-account-circle d-md-none d-block"></i>
            <span class="d-none d-md-block">Menunggu</span>
        </a>
    </li>
    <li class="nav-item">
        <a href="#disetujui" data-bs-toggle="tab" aria-expanded="false" onclick="setuju()" class="nav-link rounded-0">
            <i class="mdi mdi-home-variant d-md-none d-block"></i>
            <span class="d-none d-md-block">Disetujui</span>
        </a>
    </li>
    <li class="nav-item">
        <a href="#ditolak" data-bs-toggle="tab" aria-expanded="false" onclick="tolak()" class="nav-link rounded-0">
            <i class="mdi mdi-settings-outline d-md-none d-block"></i>
            <span class="d-none d-md-block">Ditolak</span>
        </a>
    </li>
</ul>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show " role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <i class="dripicons-checkmark me-2"></i><strong><?php echo e($message); ?></strong>
</div>
<?php elseif($message = Session::get('error')): ?>
<div class="alert alert-success alert-dismissible bg-danger text-white border-0 fade show " role="alert">
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <i class="dripicons-wrong me-2"></i><strong><?php echo e($message); ?></strong>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex">
    <div class="btn-group">
        <a href="<?php echo e(url('/pdf-req-barang')); ?>" class="btn btn-sm btn-danger mb-2">PDF</a>
        <a href="<?php echo e(url('/excel-req-barang')); ?>" class="btn btn-sm btn-success mb-2">Excel</a>
    </div>
</div>


<div class="tab-content">
    <div class="tab-pane show active" id="menunggu">
        <table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
            <thead>
                <tr>
                    <th>Barang</th>
                    <th>User</th>
                    <th>Quantity</th>
                    <th>Tanggal Request</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->where('status','menunggu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->barang->nama); ?></td>
                    <td><?php echo e($d->user->name); ?></td>
                    <td><?php echo e($d->quantity); ?></td>
                    <td><?php echo e($d->tanggal_request); ?></td>
                    <td><span class="badge bg-warning"><?php echo e(ucwords($d->status)); ?></span></td>
                    <th class="text-center">
                        <form action="<?php echo e(url('/terima-req')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                        <div class="btn-group">
                            <button type="submit" class="btn btn-success btn-sm"><i class="dripicons-checkmark"></i> Terima</button>
                            <button  type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#fill-danger-modal-<?php echo e($d->id); ?>"> <i class="dripicons-cross"></i> Tolak</button>
                        </div>
                    </form>
                    </th>
                </tr>

                <div id="fill-danger-modal-<?php echo e($d->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="fill-danger-modalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content modal-filled bg-danger">
                            <div class="modal-header">
                                <h4 class="modal-title" id="fill-danger-modalLabel">Tolak Pesanan <?php echo e($d->barang->nama); ?></h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                            </div>
                            <form action="<?php echo e(url('/tolak-req')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="example-textarea" class="form-label">Keterangan</label>
                                        <textarea name="keterangan" class="form-control bg-transparent text-white border-2 border-white" id="example-textarea" rows="5" placeholder="Kenapa di Tolak?" required ></textarea>
                                        <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-outline-light">Simpan</button>
                                </div>
                            </form>
                        </div><!-- /.modal-content -->
                    </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="tab-pane " id="disetujui">
        <table id="basic-datatable" class="basic-datatable table table-striped dt-responsive nowrap w-100">
            <thead>
                <tr>
                    <th>Barang</th>
                    <th>User</th>
                    <th>Quantity</th>
                    <th>Tanggal Request</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->where('status','disetujui'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->barang->nama); ?></td>
                    <td><?php echo e($d->user->name); ?></td>
                    <td><?php echo e($d->quantity); ?></td>
                    <td><?php echo e($d->tanggal_request); ?></td>
                    <td><span class="badge bg-success"><?php echo e(ucwords($d->status)); ?></span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="tab-pane" id="ditolak">
        <table id="basic-datatable" class="basic-datatable table table-striped dt-responsive nowrap w-100">
            <thead>
                <tr>
                    <th>Barang</th>
                    <th>User</th>
                    <th>Quantity</th>
                    <th>Tanggal Request</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data->where('status','ditolak'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->barang->nama); ?></td>
                    <td><?php echo e($d->user->name); ?></td>
                    <td><?php echo e($d->quantity); ?></td>
                    <td><?php echo e($d->tanggal_request); ?></td>
                    <td><span class="badge bg-danger"><?php echo e(ucwords($d->status)); ?></span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!-- Datatables js -->
    <script src="assets/js/vendor/jquery.dataTables.min.js"></script>
    <script src="assets/js/vendor/dataTables.bootstrap5.js"></script>
    <script src="assets/js/vendor/dataTables.responsive.min.js"></script>
    <script src="assets/js/vendor/responsive.bootstrap5.min.js"></script>
    
    <!-- Datatable Init js -->
    <script src="assets/js/pages/demo.datatable-init.js"></script>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/admin/requestbarang/index.blade.php ENDPATH**/ ?>