<!DOCTYPE html>
<html>
<head>
<style>
    #customers {
    font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    #customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
    }

    #customers tr:nth-child(even){background-color: #f2f2f2;}

    #customers tr:hover {background-color: #ddd;}

    #customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #00e5ff;
    color: black;
    }
</style>
</head>
<body>
<center>
    <h1>Data Request <?php echo e(ucwords($status)); ?></h1>
    <h5><?php echo e($date); ?></h5>
</center>
    
<table id="customers">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>User</th>
            <th>Quantity</th>
            <th>Tanggal Request</th>
            <th>Tanggal Status</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($d->barang->nama); ?></td>
                <td><?php echo e($d->user->name); ?></td>
                <td><?php echo e($d->quantity); ?></td>
                <td><?php echo e($d->tanggal_request); ?></td>
                <td><?php echo e(ucwords($d->status)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\inventory\resources\views/pdf/request.blade.php ENDPATH**/ ?>