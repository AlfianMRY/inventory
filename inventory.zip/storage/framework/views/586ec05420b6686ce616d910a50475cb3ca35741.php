<div class="leftside-menu leftside-menu-detached">

    <div class="leftbar-user ">
        <a href="<?php echo e(url('/profile',Auth::user()->id)); ?>" >
            <img src="<?php echo e(asset('/img/profile/'.Auth::user()->foto)); ?>" alt="user-image" height="42" class="rounded-circle shadow-sm">
            <span class="leftbar-user-name mx-auto"><?php echo e(ucwords(Auth::user()->name)); ?></span>
        </a>
    </div>

    <!--- Sidemenu -->
    <ul class="side-nav">

        <li class="side-nav-title side-nav-item">Navigation</li>

        <li class="side-nav-item">
            <a href="<?php echo e(url('/')); ?>" class="side-nav-link">
                <i class="uil-home-alt"></i>
                <span> Landingpage </span>
            </a>
        </li>

        <li class="side-nav-item">
            <a href="<?php echo e(url('/dashboard')); ?>" class="side-nav-link">
                <i class=" uil-chart-bar"></i>
                <span> Dashboards </span>
            </a>
        </li>
        <?php if(Auth::user()->role == 'admin'): ?>
            
        <li class="side-nav-item">
            <a data-bs-toggle="collapse" href="#sidebarDashboards" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                <i class="dripicons-folder-open"></i>
                <span> Data Master </span>
                <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="sidebarDashboards">
                <ul class="side-nav-second-level">
                    <li class="side-nav-item ps-lg-3">
                        <a href="<?php echo e(url('/kategori')); ?>" class="side-nav-link ">
                            <i class=" uil-game-structure"></i>
                            <span>Kategori</span>
                        </a>
                    </li>
                    <li class="side-nav-item ps-lg-3">
                        <a href="<?php echo e(url('/supplier')); ?>" class="side-nav-link ">
                            <i class="uil-box"></i>
                            <span>Supplier</span>
                        </a>
                    </li>
                    <li class="side-nav-item ps-lg-3">
                        <a href="<?php echo e(url('/user')); ?>" class="side-nav-link ">
                            <i class="uil-users-alt"></i>
                            <span>User</span>
                        </a>
                    </li>
                    <li class="side-nav-item ps-lg-3">
                        <a href="<?php echo e(url('/barang')); ?>" class="side-nav-link">
                            <i class="uil-dropbox"></i>
                            <span> Barang</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>

        <li class="side-nav-item">
            <a data-bs-toggle="collapse" href="#sidebarEcommerce" aria-expanded="false" aria-controls="sidebarEcommerce" class="side-nav-link">
                <i class="uil-store"></i>
                <span> Transaction </span>
                <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="sidebarEcommerce">
                <ul class="side-nav-second-level">
                    <li class="side-nav-item ps-lg-3">
                        <a href="<?php echo e(route('barang-masuk.index')); ?>" class="side-nav-link">
                            <i class=" uil-truck"></i>
                            <span> Barang Masuk</span>
                        </a>
                    </li>

                    <li class="side-nav-item ps-lg-3">
                        <a href="<?php echo e(url('/req-barang')); ?>" class="side-nav-link">
                            <i class="uil-shield-question"></i>
                            <span> Request Barang </span>
                        </a>
                    </li>

                </ul>
            </div>
        </li>
            
        
        <?php endif; ?>
        
        <li class="side-nav-item">
            <a href="<?php echo e(url('/list-barang')); ?>" class="side-nav-link">
                <i class="uil-dropbox"></i>
                <span> List Barang</span>
            </a>
        </li>
        
    </ul>

    <!-- Help Box -->
    <div class="help-box help-box-light text-center">
    </div>
    <!-- end Help Box -->
    <!-- End Sidebar -->

    <div class="clearfix"></div>
    <!-- Sidebar -left -->

</div><?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/leftbar.blade.php ENDPATH**/ ?>